export const colors = {
  main: "#1D3557",
  secondary: "#457B9D",
  cta: "#E63946",
  text: "#2b2922",
  offwhite: "#F1FAEE",
};

export const shadow = "0 5px 20px rgba(0,0,0,0.15)";
