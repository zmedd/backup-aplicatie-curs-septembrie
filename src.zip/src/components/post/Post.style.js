import styled from "styled-components";
import { colors, shadow } from "../../const/colors";

export const Container = styled.div`
  padding: 10px;
  border-radius: 5px;
  box-shadow: ${shadow};
  background-color: ${colors.offwhite};
  margin-bottom: 20px;
`;

export const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
`;

export const UserDetails = styled.div`
  display: flex;
  align-items: center;
`;

export const Avatar = styled.img`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
`;

export const UserFullName = styled.p`
  font-size: 16px;
  font-weight: 600;
`;

export const PostDate = styled.p`
  font-size: 12px;
  font-weight: 400;
`;

export const ContentWrapper = styled.div`
  & > * {
    max-width: 100%;
    display: block;
    margin: 0 auto 1rem;
  }
`;
