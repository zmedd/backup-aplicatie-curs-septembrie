import React from "react";
import {
  Container,
  Header,
  UserDetails,
  Avatar,
  UserFullName,
  PostDate,
  ContentWrapper,
} from "./Post.style";
import { users } from "../../data/users";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEllipsisV } from "@fortawesome/free-solid-svg-icons";

const Post = ({ postData }) => {
  function getAuthorData(id) {
    return users.find((user) => user.id === id);
  }

  return (
    <Container>
      <Header>
        <UserDetails>
          <Avatar src={getAuthorData(postData.author).avatar.small} />
          <div>
            <UserFullName>
              {`${getAuthorData(postData.author).first_name} ${
                getAuthorData(postData.author).last_name
              }`}
            </UserFullName>
            <PostDate>{postData.date}</PostDate>
          </div>
        </UserDetails>
        <FontAwesomeIcon icon={faEllipsisV} />
      </Header>
      <ContentWrapper>
        {postData.content.text !== undefined && <p>{postData.content.text}</p>}
        {postData.content.video !== undefined && (
          <video src={postData.content.video} controls />
        )}
        {postData.content.image.length > 0 &&
          postData.content.image.map((source, index) => (
            <img
              src={source}
              key={index}
              alt={`${getAuthorData(postData.author).first_name} ${
                getAuthorData(postData.author).last_name
              }`}
            />
          ))}
      </ContentWrapper>
    </Container>
  );
};

export default Post;
